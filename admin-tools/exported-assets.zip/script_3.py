
llm_client = '''"""
llm_client.py — Provider-agnostic wrapper. Same skill prompt + schema,
different backend model. Switch providers via LLM_PROVIDER in .env.
"""
import json
import re
import config


def _extract_json(text: str) -> dict:
    """LLMs sometimes wrap JSON in markdown fences; strip those."""
    text = text.strip()
    match = re.search(r"```(?:json)?\\s*(.*?)\\s*```", text, re.DOTALL)
    if match:
        text = match.group(1)
    return json.loads(text)


def _load_skill_prompt() -> str:
    with open(config.SKILL_FILE_PATH, "r") as f:
        return f.read()


def _build_prompt(episode_id: str, episode_title: str, transcript: str) -> str:
    skill = _load_skill_prompt()
    return f"""{skill}

## Actual input

episode_id: {episode_id}
episode_title: {episode_title}

transcript:
---
{transcript}
---

Return ONLY the JSON object described above, nothing else."""


def generate_review_json(episode_id: str, episode_title: str, transcript: str) -> dict:
    prompt = _build_prompt(episode_id, episode_title, transcript)
    provider = config.LLM_PROVIDER

    if provider == "gemini":
        return _call_gemini(prompt)
    elif provider == "openai":
        return _call_openai(prompt)
    elif provider == "anthropic":
        return _call_anthropic(prompt)
    else:
        raise ValueError(f"Unknown LLM_PROVIDER: {provider}")


def _call_gemini(prompt: str) -> dict:
    import google.generativeai as genai
    genai.configure(api_key=config.GEMINI_API_KEY)
    model = genai.GenerativeModel(config.GEMINI_MODEL)
    response = model.generate_content(prompt)
    return _extract_json(response.text)


def _call_openai(prompt: str) -> dict:
    from openai import OpenAI
    client = OpenAI(api_key=config.OPENAI_API_KEY)
    response = client.chat.completions.create(
        model=config.OPENAI_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
    )
    return _extract_json(response.choices[0].message.content)


def _call_anthropic(prompt: str) -> dict:
    import anthropic
    client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
    response = client.messages.create(
        model=config.ANTHROPIC_MODEL,
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )
    return _extract_json(response.content[0].text)
'''
with open('output/llm_client.py','w') as f:
    f.write(llm_client)

generate_review = '''"""
generate_review.py — CLI: transcript file -> review JSON via chosen LLM provider.

Usage:
    python generate_review.py --transcript s1e4fagugu-end.txt --episode-id s1e4 --out s1e4_review.json
    python generate_review.py --transcript s1e4fagugu-end.txt --episode-id s1e4 --provider openai
"""
import argparse
import json
import sys
import config
from llm_client import generate_review_json


def main():
    parser = argparse.ArgumentParser(description="Generate review JSON from transcript via LLM")
    parser.add_argument("--transcript", required=True, help="Path to transcript .txt file")
    parser.add_argument("--episode-id", required=True, help="Internal episode id, e.g. s1e4")
    parser.add_argument("--episode-title", default="", help="Episode title (optional)")
    parser.add_argument("--provider", default=None,
                         help="Override LLM_PROVIDER from .env (gemini|openai|anthropic)")
    parser.add_argument("--out", default=None, help="Output JSON file path (default: stdout)")
    args = parser.parse_args()

    if args.provider:
        config.LLM_PROVIDER = args.provider.lower()

    with open(args.transcript, "r", encoding="utf-8") as f:
        transcript_text = f.read()

    result = generate_review_json(args.episode_id, args.episode_title, transcript_text)

    output_str = json.dumps(result, indent=2)
    if args.out:
        with open(args.out, "w") as f:
            f.write(output_str)
        print(f"Saved review JSON to {args.out}")
    else:
        print(output_str)


if __name__ == "__main__":
    main()
'''
with open('output/generate_review.py','w') as f:
    f.write(generate_review)
print("llm_client + generate_review written")
