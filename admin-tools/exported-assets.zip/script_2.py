
config_py = '''"""Central config: loads .env, exposes constants used across the pipeline."""
import os
from dotenv import load_dotenv

load_dotenv()

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "gemini").lower()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o")

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")

OMDB_API_KEY = os.getenv("OMDB_API_KEY", "")
OMDB_BASE_URL = "http://www.omdbapi.com/"
SHOW_TITLE = "Family Guy"

SUPABASE_URL = os.getenv("SUPABASE_URL", "https://tupubifayvovrzqyemee.supabase.co")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY", "")

# Cohost name -> UUID map (update here if hosts/UUIDs change)
COHOST_UUIDS = {
    "Jason": "01201e1a-dafd-424a-b596-ff9ece65f1aa",
    "Collin": "0a3dfd13-90b2-47db-b0af-2e0c0df21cff",
    "Tyler": "e08c8c4b-ecf5-427e-8890-fe9cef0a2c9a",
}

SKILL_FILE_PATH = os.path.join(os.path.dirname(__file__), "transcript_review_skill.md")
'''
with open('output/config.py','w') as f:
    f.write(config_py)

omdb_fetch = '''"""
omdb_fetch.py — Backfill the `episodes` table from the OMDb API.

Usage:
    python omdb_fetch.py --season 1 --episode 4 --episode-id s1e4
    python omdb_fetch.py --season 1 --episode 4 --episode-id s1e4 --dry-run
"""
import argparse
import sys
import requests
from supabase import create_client
import config


def fetch_episode_metadata(season: int, episode: int) -> dict:
    params = {
        "t": config.SHOW_TITLE,
        "Season": season,
        "Episode": episode,
        "apikey": config.OMDB_API_KEY,
    }
    resp = requests.get(config.OMDB_BASE_URL, params=params, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    if data.get("Response") == "False":
        raise ValueError(f"OMDb error: {data.get('Error')}")
    return data


def map_to_episodes_row(episode_id: str, season: int, episode: int, omdb_data: dict) -> dict:
    def split_list(s):
        if not s or s == "N/A":
            return []
        return [x.strip() for x in s.split(",")]

    return {
        "id": episode_id,
        "season": season,
        "episode_number": episode,
        "title": omdb_data.get("Title", ""),
        "air_date": omdb_data.get("Released", ""),
        "runtime": omdb_data.get("Runtime", ""),
        "imdb_rating": omdb_data.get("imdbRating", ""),
        "summary": omdb_data.get("Plot", ""),
        "cast": split_list(omdb_data.get("Actors", "")),
        "writers": split_list(omdb_data.get("Writer", "")),
        "director": omdb_data.get("Director", ""),
    }


def upsert_episode(row: dict, dry_run: bool = False):
    if dry_run:
        print("[DRY RUN] Would upsert into `episodes`:")
        for k, v in row.items():
            print(f"  {k}: {v}")
        return
    client = create_client(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY)
    result = client.table("episodes").upsert(row).execute()
    print("Upserted episode:", result.data)


def main():
    parser = argparse.ArgumentParser(description="Backfill episodes table from OMDb")
    parser.add_argument("--season", type=int, required=True)
    parser.add_argument("--episode", type=int, required=True)
    parser.add_argument("--episode-id", type=str, required=True,
                         help="Internal episode id, e.g. s1e4")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if not config.OMDB_API_KEY:
        sys.exit("OMDB_API_KEY not set in .env")

    omdb_data = fetch_episode_metadata(args.season, args.episode)
    row = map_to_episodes_row(args.episode_id, args.season, args.episode, omdb_data)
    upsert_episode(row, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
'''
with open('output/omdb_fetch.py','w') as f:
    f.write(omdb_fetch)
print("config + omdb_fetch written")
